public class Eccezioni extends Exception {
	/**
	 * @see eccezione generica 
	 */
    void EccezioniInputVuoto()
          {
	    	
          }
}