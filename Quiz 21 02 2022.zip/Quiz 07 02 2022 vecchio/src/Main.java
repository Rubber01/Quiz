import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Main {
	/**
	 * @version v.2.1
	 * @author Pietro Biasotti, Aimen Essaidi, Islam Ouarem, Matthias Stocchi
	 * @param args
	 * @throws Eccezioni
	 * @throws IOException
	 * @bug Problema matrici @class Quiz
	 * 
	 */
	public static void main(String[] args)throws Eccezioni, IOException{
		/*Estrai es=new Estrai();
		es.LangText("Text.txt");
		es.splitUser("Users.txt");
		*/
		/*Valid validator= new Valid();
		
		
		System.out.println(validator.checkCredentials("Mikado", "Ringo"));*/
		
		
		
		App application =new App();
		application.start();
		
		
    }
		
        
        /*
        registration registrator = new registration();
        registrator.enterCredentials();
        registrator.saveCredentials();*/
}

	



